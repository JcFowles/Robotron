/*TO DO LIST*/

/*
* 
* Return error ints for initialize sockets
* MAP key inputs to be defined by user � changeable controls
* multiple servers on same pc
* 
/*



/*Prevent buffer over run when converting data packet structs*/

/*stop empty names*/

/*Server full - Race to user name*/

//bool checkSockaddr(sockaddr_in const &a, sockaddr_in const &b) { return a.sin_addr.S_un.S_addr == b.sin_addr.S_un.S_addr; }